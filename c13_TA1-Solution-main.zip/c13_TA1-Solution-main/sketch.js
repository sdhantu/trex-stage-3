var input, heading;

function setup() {
  
  createCanvas(300, 200);
  background(178,255,102);
  
  input = createInput();
  input.position(5, 60);

  heading = createElement('h4', 'Enter any alphabet:');
  heading.position(5, 20);
    
  textAlign(CENTER);
  textSize(50);
}

function draw() {

  var value = input.value();
  switch (value) {
      
    case 'a':
      console.log("Vowel");
      break;
      
    case 'e':
      console.log("Vowel");
      break;
      
    case 'i':
      console.log("Vowel");
      break;
      
    case 'o':
      console.log("Vowel");  
      break;
      
    case 'u':
      console.log("Vowel");  
      break;
      
    default:
      console.log("Please enter any character"); 
  }
}


